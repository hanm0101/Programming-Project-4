# PPA_CW4

Project: Airbnb - PPA_CW4
Authors: Faith Ong, Hana Mizukami, Sadiyah Khanam, Zeineb Bouchamaoui

This project is part of our fourth assignment for the PPA module.



How to start:
   Start the Main application.
    Then select a price range in the Login Panel, you can also create or login to an account.
    From Login Panel you can click on next to go to the Map Panel and that also opens a Stat Window, and previous to go to the Features Panel.
    In the map panel, the user can see a map of London. Each time they change the price range, the map updates and a new stat window opens. If they click on the borough then a window opens with the properties in that borough. From that window, the user can access more detailed informations about each individual property.
    From Map Panel you can click on next to go to the Login Panel, and previous to go to the Search Panel.
    From Search Panel you can click on next to go to the Map Panel, and previous to go to the Features Panel.
    From Features Panel you can click on next to go to the Search Panel, and previous to go to the Login Panel.
    
